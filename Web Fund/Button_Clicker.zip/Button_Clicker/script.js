function logout(element) {
    element.innerText = "Logout"
}
function remove(element) {
    element.remove();
}
function ninja(element) {
    alert("Ninja was liked");
}