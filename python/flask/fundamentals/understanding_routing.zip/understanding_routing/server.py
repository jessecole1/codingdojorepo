from flask import Flask
app = Flask(__name__)

@app.route('/say/<name>')
def hi(name):
    return 'Hi ' + name.capitalize() + '!'

@app.route('/dojo')
def dojo():
    return 'Dojo!'

@app.route('/repeat/<string:name>/<int:num>')
def repeat(name, num):
    return (' ' + name * num)

@app.route('/')
def function():
    return 'Hello World!'

if __name__ == "__main__":
    app.run(debug=True)